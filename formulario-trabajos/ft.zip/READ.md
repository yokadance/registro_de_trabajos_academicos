## 📋 Instrucciones de Instalación

1. **Crea el plugin:**
   - Ve a `wp-content/plugins/`
   - Crea carpeta: `formulario-trabajos`
   - Crea archivo: `formulario-trabajos.php`
   - Pega el código anterior

2. **Activa el plugin:**
   - WordPress Admin → Plugins → Activar "Formulario de Trabajos Académicos"

3. **Usa el shortcode en una página:**
```
   [formulario_trabajos]